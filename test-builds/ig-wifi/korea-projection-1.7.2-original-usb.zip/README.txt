Korea Projection 1.7.2 - USB 설치 파일
(NEMESIS Manager 목록에서는 "Korea Projection: Wireless for Korean Cars"로 보입니다)

1. USB를 FAT32로 포맷합니다(32GB 이하 USB 권장).
2. 이 폴더 "안에 있는 것"을 USB 맨 위에 그대로 복사합니다.
     USB
     ├─ NEMESIS.data
     ├─ README.txt
     └─ packages
         └─ korea.projection.zip   ← 이 파일은 압축을 풀지 마세요
   폴더째로 넣으면 안 됩니다. USB를 열었을 때 NEMESIS.data가 바로 보여야 합니다.
   (BUSYBOX-LICENSE.txt는 함께 들어 있는 busybox의 라이선스 안내입니다. USB에 같이 복사해도 됩니다.)
3. 시동을 켜고 내비 화면이 다 뜬 뒤 USB를 꽂습니다.
4. 설치할지 물으면 60초 안에 "예"를 누릅니다.
5. 설치가 끝나면 USB를 빼고 기다립니다. "설정을 마쳤습니다"가 뜨면 내비를 재부팅합니다.
   시동만 끄면 내비가 꺼지지 않을 수 있습니다. 내비 본체의 RESET 버튼(작은 구멍)을 클립으로 누르거나,
   NEMESIS Manager에서 재부팅을 누르세요.

자세한 설명:
https://github.com/StopDragon/korea-projection/blob/main/docs/install-guide.md
